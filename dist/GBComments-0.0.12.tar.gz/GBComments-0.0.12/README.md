# 这是一个用于自动生成好评差评的包

## data文件夹里面的data.py

里面放置了好评差评的语句

## GBComments.py

里面放置了生成评论的逻辑

使用方法

```python
from GBComments import produceComments
produceComments()
```

